
/**
 * @author Ethan Anwar
 * @category Personal finance
 */
module bbva_desktop_app {
	requires java.desktop;
	requires java.xml.crypto;
}