package main.resources.visual.swingcomponents;

import javax.swing.UnsupportedLookAndFeelException; 

public class RoundedBorder extends javax.swing.JFrame { 

	private static final long serialVersionUID = 490598333515399630L;
	// Creates new form RoundButton 
	public RoundedBorder() { 
		initComponents(); 
	} 

	// <editor-fold defaultstate="collapsed" desc="Generated Code">						 
	private void initComponents() 
	{ 
	} 
	
	public static void main(String args[]) throws UnsupportedLookAndFeelException, ClassNotFoundException { 
		// try-catch block to handle InstantiationException 
		
		java.awt.EventQueue.invokeLater(new Runnable() { 
			@Override
			public void run() { 
				new RoundedBorder().setVisible(true); 
			} 

		}); 
		//</editor-fold> 

	} 

	// Variables declaration - do not modify					 
	/*private javax.swing.JButton jButton1; 
	private javax.swing.JLabel jLabel1; 
	private javax.swing.JButton testbtn2; 
	private javax.swing.JButton testbtn3; */
	// End of variables declaration				 
} 
